import torch
import torchvision
import torchvision.transforms as transforms
import numpy as np
from torch.utils.data import DataLoader, Subset

def get_cifar100_data(data_dir="./data", batch_size=128, labeled_ratio=0.1, seed=42):
    """
    CIFAR-100 데이터셋을 로드하고 labeled(10%) / unlabeled(90%)로 분리하는 함수.

    Args:
        data_dir (str): 데이터셋 다운로드 위치
        batch_size (int): 배치 크기
        labeled_ratio (float): labeled 데이터 비율 (기본값 10%)
        seed (int): 랜덤 시드

    Returns:
        labeled_loader (DataLoader): Labeled 데이터 로더 (10%)
        unlabeled_loader (DataLoader): Unlabeled 데이터 로더 (90%)
        test_loader (DataLoader): Test 데이터 로더
    """

    # ✅ 기본적인 데이터 변환 (Labeled 데이터)
    transform_labeled = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5071, 0.4867, 0.4408], std=[0.2675, 0.2565, 0.2761])
    ])

    # ✅ Self-SL용 데이터 변환 (Unlabeled 데이터, 더 강한 증강 적용)
    transform_unlabeled = transforms.Compose([
        transforms.RandomResizedCrop(32, scale=(0.2, 1.0)),  # 다양한 크기로 변형
        transforms.RandomHorizontalFlip(),
        transforms.RandomApply([transforms.ColorJitter(0.4, 0.4, 0.4, 0.1)], p=0.8),  # 색상 변화
        transforms.RandomGrayscale(p=0.2),  # 흑백 변환 20%
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5071, 0.4867, 0.4408], std=[0.2675, 0.2565, 0.2761])
    ])

    # ✅ 테스트 데이터 변환 (Labeled 데이터와 동일)
    transform_test = transform_labeled

    # CIFAR-100 데이터셋 로드
    full_train_dataset = torchvision.datasets.CIFAR100(root=data_dir, train=True, download=True)
    test_dataset = torchvision.datasets.CIFAR100(root=data_dir, train=False, download=True, transform=transform_test)

    # 랜덤 시드 고정 (재현성을 위해)
    np.random.seed(seed)

    # ✅ Labeled / Unlabeled 데이터셋 분리
    labeled_indices = []
    unlabeled_indices = []
    class_counts = {i: 0 for i in range(100)}  # CIFAR-100: 100개 클래스

    for idx, (_, label) in enumerate(full_train_dataset):
        if class_counts[label] < (500 * labeled_ratio):  # 각 클래스당 10% (50개)
            labeled_indices.append(idx)
        else:
            unlabeled_indices.append(idx)
        class_counts[label] += 1

    # ✅ Subset을 사용하여 데이터셋 나누기
    labeled_dataset = Subset(full_train_dataset, labeled_indices)
    unlabeled_dataset = Subset(full_train_dataset, unlabeled_indices)

    # ✅ 변환 적용 (Labeled / Unlabeled)
    labeled_dataset.dataset.transform = transform_labeled
    unlabeled_dataset.dataset.transform = transform_unlabeled

    # ✅ DataLoader 생성
    labeled_loader = DataLoader(labeled_dataset, batch_size=batch_size, shuffle=True, num_workers=4)
    unlabeled_loader = DataLoader(unlabeled_dataset, batch_size=batch_size, shuffle=True, num_workers=4)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=4)

    return labeled_loader, unlabeled_loader, test_loader

if __name__ == "__main__":
    # ✅ 데이터 로더 테스트
    labeled_loader, unlabeled_loader, test_loader = get_cifar100_data()
    print(f"✅ Labeled Data: {len(labeled_loader.dataset)} samples")
    print(f"✅ Unlabeled Data: {len(unlabeled_loader.dataset)} samples")
    print(f"✅ Test Data: {len(test_loader.dataset)} samples")
