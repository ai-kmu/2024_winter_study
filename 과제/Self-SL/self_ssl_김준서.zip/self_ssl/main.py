import torch
import torch.optim as optim
import os
import multiprocessing

from dataset import get_cifar100_data
from model import ResNetSelfSL
from pretrain import MoCo, pretrain_loop  # MoCo 모델과 학습 함수
from train import fine_tune_loop  # Fine-tuning 함수

# ✅ Windows에서 multiprocessing 문제 해결 (DataLoader 사용 시 필수)
if __name__ == '__main__':
    multiprocessing.set_start_method('spawn', force=True)  # ✅ Windows에서 필수

    # 학습 설정
    EPOCHS_PRETRAIN = 30  # MoCo Pretraining Epochs
    EPOCHS_FINE_TUNE = 20  # Fine-tuning Epochs
    BATCH_SIZE = 128
    DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # ✅ 저장 폴더 생성 (없으면 자동 생성)
    save_path = "./checkpoints"
    os.makedirs(save_path, exist_ok=True)

    # ✅ 데이터 로드 (labeled 10%, unlabeled 90%)
    labeled_loader, unlabeled_loader, test_loader = get_cifar100_data(batch_size=BATCH_SIZE)

    # ✅ MoCo 모델 생성 (한 번만 수행)
    moco_model = MoCo(ResNetSelfSL, dim=128).to(DEVICE)
    optimizer_pretrain = optim.SGD(moco_model.parameters(), lr=0.03, momentum=0.9, weight_decay=1e-4)

    # ✅ Self-Supervised Learning (MoCo Pretraining)
    print("\n🚀 Self-Supervised Pretraining (MoCo) 시작...")
    pretrain_loop(moco_model, optimizer_pretrain, unlabeled_loader, DEVICE, EPOCHS_PRETRAIN)

    # ✅ Pretrained 모델 저장
    torch.save(moco_model.state_dict(), os.path.join(save_path, "moco_pretrained_final.pth"))
    print("✅ Pretrained MoCo 모델 저장 완료!")

    # ✅ Fine-tuning을 위한 ResNet 모델 생성 (MoCo Query Encoder 활용)
    model = moco_model.encoder_q  # Query Encoder를 Fine-tuning
    model.fc = torch.nn.Linear(512, 100)  # CIFAR-100 클래스 개수 조정
    model = model.to(DEVICE)
    optimizer_finetune = optim.Adam(model.parameters(), lr=0.001)

    # ✅ Supervised Learning (Fine-tuning)
    print("\n🔥 Fine-tuning 시작...")
    fine_tune_loop(model, optimizer_finetune, labeled_loader, DEVICE, EPOCHS_FINE_TUNE)

    # ✅ Fine-tuned 모델 저장
    torch.save(model.state_dict(), os.path.join(save_path, "selfsl_finetuned_final.pth"))
    print("✅ Fine-tuned 모델 저장 완료!")

    print("\n🎯 전체 학습 완료! MoCo Pretrained 모델과 Fine-tuned 모델이 저장되었습니다.")
