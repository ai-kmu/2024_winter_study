import torch
import torch.optim as optim
from dataset import get_cifar100_data
from model import ResNetSelfSL
from train import fine_tune_loop  # Supervised 학습 루프

# 학습 설정
EPOCHS_BASELINE = 50  # 지도학습 Epochs
BATCH_SIZE = 128
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

if __name__ == '__main__':  # ✅ Windows에서 multiprocessing 사용 시 필수!
    # ✅ 데이터 로드 (labeled 10%만 사용)
    labeled_loader, _, test_loader = get_cifar100_data(batch_size=BATCH_SIZE)

    # ✅ Baseline 모델 생성
    model = ResNetSelfSL(feature_dim=100).to(DEVICE)  # 🔹 Fully Supervised이므로 CIFAR-100용 100차원 출력
    optimizer_baseline = optim.Adam(model.parameters(), lr=0.001)

    # ✅ 지도학습 (Supervised Learning)
    print("\n🔥 Supervised Baseline Training 시작...")
    fine_tune_loop(model, optimizer_baseline, labeled_loader, DEVICE, EPOCHS_BASELINE)

    # ✅ Baseline 모델 저장
    torch.save(model.state_dict(), "./checkpoints/baseline_trained.pth")
    print("✅ Baseline 모델 저장 완료!")

    print("\n🎯 Baseline Training 완료! Supervised 모델이 저장되었습니다.")
