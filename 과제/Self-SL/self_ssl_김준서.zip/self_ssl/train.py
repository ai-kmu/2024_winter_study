import torch
import torch.nn as nn
from tqdm import tqdm

# ✅ Fine-tuning Loop
def fine_tune_loop(model, optimizer, labeled_loader, DEVICE, EPOCHS):
    criterion = nn.CrossEntropyLoss()
    print(f"🔥 Fine-tuning ({EPOCHS} epochs) 시작!")

    for epoch in range(1, EPOCHS + 1):
        model.train()
        running_loss = 0.0
        correct = 0
        total = 0

        loop = tqdm(labeled_loader, desc=f"Epoch [{epoch}/{EPOCHS}]", leave=True)

        for images, labels in loop:
            images, labels = images.to(DEVICE), labels.to(DEVICE)

            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()

            _, predicted = outputs.max(1)
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()

            loop.set_postfix(loss=loss.item(), acc=100. * correct / total)

        epoch_loss = running_loss / len(labeled_loader)
        epoch_acc = 100. * correct / total
        print(f"✅ Epoch {epoch}: Loss={epoch_loss:.4f}, Accuracy={epoch_acc:.2f}%")
