import torch
import torch.nn as nn
import torchvision.models as models

class ResNetSelfSL(nn.Module):
    def __init__(self, feature_dim=128):
        super(ResNetSelfSL, self).__init__()
        self.model = models.resnet18(pretrained=False)  # ✅ pretrained=False 명시적으로 설정
        in_features = self.model.fc.in_features  # ✅ 512 대신 동적으로 in_features 사용
        self.model.fc = nn.Linear(in_features, feature_dim)  # ✅ feature_dim 크기 출력

    def forward(self, x):
        q = self.model(x)
        q = nn.functional.normalize(q, dim=1)  # ✅ L2 정규화 추가 (선택)
        return q

if __name__ == "__main__":
    model = ResNetSelfSL(feature_dim=128)  # ✅ 128차원 feature 출력 확인
    x = torch.randn(2, 3, 32, 32)  # CIFAR-100 이미지 크기
    output = model(x)
    print(output.shape)  # ✅ (2, 128) 확인
