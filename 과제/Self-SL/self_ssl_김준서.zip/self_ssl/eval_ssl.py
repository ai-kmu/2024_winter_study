import torch
import torch.nn as nn
from dataset import get_cifar100_data
from model import ResNetSelfSL

# ✅ 설정
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
BATCH_SIZE = 128
MODEL_PATH = "./checkpoints/selfsl_finetuned_50.pth"  # ✅ Fine-Tuned Self-Supervised 모델 경로

# ✅ 데이터 로드 (테스트 데이터만)
_, _, test_loader = get_cifar100_data(batch_size=BATCH_SIZE)

# ✅ Loss 함수 정의
criterion = nn.CrossEntropyLoss()

def evaluate():
    """Self-Supervised Fine-Tuned 모델 평가"""
    print(f"\n🚀 **Self-Supervised Fine-Tuned 모델 평가 시작...**")

    # ✅ 모델 로드
    model = ResNetSelfSL(feature_dim=128).to(DEVICE)  # 원래 저장된 feature_dim=128
    model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE), strict=False)  # 🔹 strict=False 설정
    model.fc = nn.Linear(512, 100).to(DEVICE)  # 🔹 CIFAR-100용 fc 레이어 변경

    model.eval()

    # ✅ Loss 및 Accuracy 계산
    total_loss = 0.0
    correct = 0
    total = 0

    with torch.no_grad():
        for images, labels in test_loader:
            images, labels = images.to(DEVICE), labels.to(DEVICE)

            outputs = model(images)
            loss = criterion(outputs, labels)
            total_loss += loss.item()

            _, predicted = outputs.max(1)
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()

    avg_loss = total_loss / len(test_loader)
    accuracy = 100. * correct / total

    print(f"\n🎯 **Self-Supervised Fine-Tuned 모델 Evaluation 결과**")
    print(f"✅ Test Loss: {avg_loss:.4f}")
    print(f"✅ Test Accuracy: {accuracy:.2f}%")
    print("-" * 50)

if __name__ == "__main__":
    evaluate()
