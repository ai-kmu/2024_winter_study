import os
import cv2

def read_annotation_file(annotation_file):
    """ WiderFace annotation 파일을 읽어 리스트로 변환 (BOM 제거 포함) """
    with open(annotation_file, "r", encoding="utf-8-sig") as f:
        return [line.strip() for line in f.readlines() if line.strip()]

def get_image_size(image_path):
    """ 이미지 크기 가져오기 (폭, 높이) """
    image_path = os.path.abspath(image_path)  # 절대 경로 변환
    img = cv2.imread(image_path)
    if img is None:
        print(f"⚠️ 이미지 없음: {image_path}")
        return None, None
    return img.shape[1], img.shape[0]  # (width, height)
