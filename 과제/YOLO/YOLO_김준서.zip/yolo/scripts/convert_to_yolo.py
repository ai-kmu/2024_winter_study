import os
from utils import read_annotation_file, get_image_size

# WiderFace 라벨 파일 경로
ANNOTATION_FILES = {
    "train": "../dataset/wider_face_split/wider_face_train_bbx_gt.txt",
    "val": "../dataset/wider_face_split/wider_face_val_bbx_gt.txt"
}

# 이미지 및 라벨 저장 폴더
IMAGE_DIRS = {
    "train": "../dataset/WIDER_train/images",
    "val": "../dataset/WIDER_val/images"
}

LABEL_DIRS = {
    "train": "../dataset/WIDER_train/labels",
    "val": "../dataset/WIDER_val/labels"
}

# 디렉토리 생성
for key in LABEL_DIRS:
    os.makedirs(LABEL_DIRS[key], exist_ok=True)

def convert_wider_to_yolo(annotation_file, image_dir, label_dir):
    """ WiderFace bounding box를 YOLO 포맷으로 변환 """
    lines = read_annotation_file(annotation_file)
    i = 0
    while i < len(lines):
        image_path = lines[i].strip()

        # 이미지 경로 변환 (서브 폴더 포함)
        img_full_path = os.path.join(image_dir, image_path)
        img_full_path = os.path.normpath(img_full_path)  # 경로 정리

        # 이미지 크기 가져오기
        img_w, img_h = get_image_size(img_full_path)
        if img_w is None or img_h is None:
            i += 1
            continue

        # YOLO 라벨 저장 경로 (원본 구조 유지)
        label_subdir = os.path.dirname(image_path)
        label_save_dir = os.path.join(label_dir, label_subdir)
        os.makedirs(label_save_dir, exist_ok=True)

        # YOLO 라벨 파일명
        label_filename = os.path.basename(image_path).replace(".jpg", ".txt")
        label_path = os.path.join(label_save_dir, label_filename)

        num_faces = int(lines[i + 1].strip())  # 얼굴 개수
        i += 2

        yolo_labels = []
        for j in range(num_faces):
            try:
                x, y, w, h, *_ = map(int, lines[i + j].strip().split())
                x_center = (x + w / 2) / img_w
                y_center = (y + h / 2) / img_h
                width = w / img_w
                height = h / img_h
                yolo_labels.append(f"0 {x_center:.6f} {y_center:.6f} {width:.6f} {height:.6f}")
            except ValueError:
                print(f"⚠️ 잘못된 Bounding Box 데이터: {lines[i + j]}")
                continue

        # YOLO 라벨 파일 저장
        with open(label_path, "w") as f:
            f.write("\n".join(yolo_labels))

        print(f"✅ {label_filename} 변환 완료! ({label_path})")
        i += num_faces  # 다음 이미지로 이동

# 변환 실행
convert_wider_to_yolo(ANNOTATION_FILES["train"], IMAGE_DIRS["train"], LABEL_DIRS["train"])
convert_wider_to_yolo(ANNOTATION_FILES["val"], IMAGE_DIRS["val"], LABEL_DIRS["val"])

print("🎯 모든 데이터셋 변환 완료!")
