from ultralytics import YOLO
import os
from multiprocessing import freeze_support  # ✅ Windows 멀티프로세싱 문제 해결

if __name__ == "__main__":
    freeze_support()  # ✅ 멀티프로세싱 오류 방지 (필요한 경우)

    # 절대경로로 dataset.yaml 설정
    dataset_path = os.path.abspath("dataset.yaml")

    # YOLOv8 모델 불러오기
    model = YOLO("yolov8n.pt")

    # 모델 학습
    model.train(
        data=dataset_path,  # 🔹 절대경로로 수정
        epochs=20,
        imgsz=512,
        batch=16,
        workers=4,  # ✅ 필요시 2로 줄이거나 0으로 설정
        verbose=True
    )
