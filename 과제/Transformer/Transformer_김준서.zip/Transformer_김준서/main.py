import wandb
from dataset_loader import load_and_preprocess
from model_loader import load_model
from train import train  # ✅ TrainingArguments는 `train.py`에서 관리

# WandB 초기화
wandb.init(project="LLaMA-KorQuAD-Finetuning", name="LLaMA-1B-LoRA")

print(" 전체 실행 시작!")
print("데이터 로드 및 모델 로드 중...")

# 데이터셋 로드 및 전처리
tokenized_train, tokenized_val, tokenizer = load_and_preprocess()

print("✅ 데이터 로딩 완료!")
print(f"훈련 데이터 배치 크기: {len(tokenized_train)}")
print(f"검증 데이터 배치 크기: {len(tokenized_val)}")

# 모델 로드
model, tokenizer = load_model()

print("✅ 모델 로딩 완료!")

# 학습 실행
print("Fine-Tuning 시작!")
train(model, tokenized_train, tokenized_val, tokenizer)

print("Fine-Tuning 완료!")
wandb.finish()

# 학습이 끝나면 메시지 출력
print("\n✅ 학습이 완료되었습니다! `test.py`를 실행하여 평가하세요.")
