from transformers import Trainer, TrainingArguments, get_scheduler
import wandb
import evaluate as hf_evaluate
import torch
from transformers import AdamW

# 정확도 계산을 위한 메트릭 로드
metric = hf_evaluate.load("accuracy")

# 정확도 계산 함수
def compute_metrics(p):
    with torch.no_grad():
        predictions, labels = p
        predictions = torch.argmax(torch.tensor(predictions), dim=-1)
    return metric.compute(predictions=predictions, references=labels)


def train(model, tokenized_train, tokenized_val, tokenizer):
    print("🚀 모델 학습 시작!")

    # TrainingArguments 설정
    training_args = TrainingArguments(
        output_dir="./results",
        per_device_train_batch_size=2,
        per_device_eval_batch_size=8,  # 평가 배치 크기 (검증하지 않으므로 사실 의미 없음)
        gradient_accumulation_steps=2,
        num_train_epochs=3,
        logging_dir="./logs",
        logging_steps=10,
        evaluation_strategy="no",  # 검증을 수행하지 않음
        save_strategy="epoch",  # 매 epoch마다 모델 저장
        save_total_limit=2,  # 저장되는 모델의 최대 개수 제한
        load_best_model_at_end=False,  # 훈련 후 가장 좋은 모델을 로드하지 않음
        fp16=True,
        metric_for_best_model="eval_loss",  # 이 항목은 사실 사용할 필요 없음 (검증을 하지 않으므로)
        report_to="wandb",
        run_name="LLaMA-KorQuAD-Finetuning",
        warmup_steps=500,
        weight_decay=0.01,
        learning_rate=1e-4,
        lr_scheduler_type="cosine",  # 코사인 학습률 스케줄러
    )

    # 옵티마이저 설정 (AdamW 기본 옵티마이저 사용)
    optimizer = AdamW(model.parameters(), lr=training_args.learning_rate, weight_decay=training_args.weight_decay)

    # 학습률 스케줄러 설정 (코사인 감소)
    num_training_steps = len(tokenized_train) * training_args.num_train_epochs // training_args.per_device_train_batch_size
    lr_scheduler = get_scheduler(
        name=training_args.lr_scheduler_type,
        optimizer=optimizer,
        num_warmup_steps=training_args.warmup_steps,
        num_training_steps=num_training_steps
    )

    # LoRA 외의 모든 파라미터를 고정
    for name, param in model.named_parameters():
        if "q_proj" not in name and "v_proj" not in name:
            param.requires_grad = False  # LoRA가 적용된 레이어만 학습 가능하도록 설정

    # Trainer 정의
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized_train,
        eval_dataset=tokenized_val,
        compute_metrics=compute_metrics,
        optimizers=(optimizer, lr_scheduler),  # 옵티마이저와 학습률 스케줄러를 트레이너에 전달
    )

    model.train()
    print(" Trainer 학습 시작!")

    # ✅ `Trainer.train()` 실행
    trainer.train()

    print("Trainer 학습 완료!")

    # ✅ 모델 저장
    save_path = "./saved_model"
    print(f"모델을 `{save_path}`에 저장 중...")
    model.save_pretrained(save_path)
    tokenizer.save_pretrained(save_path)
    print(f"모델 저장 완료: `{save_path}`")
