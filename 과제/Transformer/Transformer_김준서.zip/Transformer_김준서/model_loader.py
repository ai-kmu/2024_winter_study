from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
import torch
from peft import LoraConfig, get_peft_model

MODEL_NAME = "meta-llama/Llama-3.2-1B"

def load_model():
    """LLaMA 모델을 로드하고 4-bit 양자화 + LoRA 적용"""
    print(" LLaMA 모델 로드 중...")

    # 4-bit 양자화 설정
    quantization_config = BitsAndBytesConfig(
        load_in_4bit=True,  # 4-bit 양자화 적용
        bnb_4bit_compute_dtype=torch.float16,  # 연산에 FP16 사용
        bnb_4bit_use_double_quant=True,  # 이중 양자화 사용 (더 최적화)
        bnb_4bit_quant_type="nf4",  # NormalFloat4 타입 사용 (최신형)
    )

    # 4-bit 양자화 모델 로드
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_NAME,
        quantization_config=quantization_config,
        device_map="auto",  # GPU 자동 할당
    )

    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    tokenizer.add_special_tokens({'pad_token': '[PAD]', 'eos_token': '</s>'})

    # LoRA 설정
    print(" LoRA 적용 중...")
    peft_config = LoraConfig(
        r=32,  # LoRA 차원을 16으로 증가
        lora_alpha=32,  # alpha 값을 16으로 증가
        lora_dropout=0.2,  # 드롭아웃 비율을 0.2로 증가
        target_modules=["q_proj", "v_proj"],  # LLaMA에서 LoRA 적용할 레이어
        bias="none",
        task_type="CAUSAL_LM",
    )

    model = get_peft_model(model, peft_config)

    # 모델을 GPU로 이동
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(device)

    print(" LLaMA 모델 로드 및 LoRA 적용 완료! (4-bit 양자화)")

    # 모든 파라미터 freeze (LoRA 파라미터는 예외)
    for name, param in model.named_parameters():
        if "q_proj" not in name and "v_proj" not in name:  # LoRA가 적용된 레이어는 제외
            param.requires_grad = False  # freeze

    # 학습되는 파라미터들 확인
    print("\n=== 학습되는 파라미터들 ===")
    for name, param in model.named_parameters():
        if param.requires_grad:
            print(name)  # 학습되는 파라미터들

    print("\n=== 학습되지 않는 파라미터들 ===")
    for name, param in model.named_parameters():
        if not param.requires_grad:
            print(name)  # 학습되지 않는 (freeze된) 파라미터들

    return model, tokenizer
