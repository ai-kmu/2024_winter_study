import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from torch.utils.data import DataLoader
import torch.nn.functional as F
from tqdm import tqdm
import evaluate as hf_evaluate

# 저장된 모델 경로
MODEL_PATH = "./saved_model"

# 모델 & 토크나이저 불러오기
device = "cuda" if torch.cuda.is_available() else "cpu"
tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
model = AutoModelForCausalLM.from_pretrained(MODEL_PATH).to(device)
model.eval()  # 평가 모드

# 검증 데이터셋 로드
from dataset_loader import load_and_preprocess
_, tokenized_val, _ = load_and_preprocess()

# collate_fn: DataLoader가 리스트가 아닌 Tensor를 반환하도록 설정
def collate_fn(batch):
    """
    배치를 PyTorch Tensor로 변환하는 함수
    """
    input_ids = torch.tensor([b["input_ids"] for b in batch], dtype=torch.long)
    attention_mask = torch.tensor([b["attention_mask"] for b in batch], dtype=torch.long)
    labels = torch.tensor([b["labels"] for b in batch], dtype=torch.long)

    return {
        "input_ids": input_ids,
        "attention_mask": attention_mask,
        "labels": labels
    }

# DataLoader 생성 (batch_size=8)
val_dataloader = DataLoader(tokenized_val, batch_size=8, shuffle=False, collate_fn=collate_fn)

# 평가 메트릭 로드
metric = hf_evaluate.load("accuracy")

# 손실 함수 정의
loss_fn = torch.nn.CrossEntropyLoss(ignore_index=-100)  # 패딩 부분(-100) 무시

# 평가 함수
def evaluate(model, dataloader):
    total_loss = 0
    total_samples = 0
    all_predictions = []
    all_labels = []

    with torch.no_grad():
        for batch in tqdm(dataloader, desc="Evaluating"):
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            labels = batch["labels"].to(device)

            # 모델 예측
            outputs = model(input_ids, attention_mask=attention_mask, labels=labels)
            logits = outputs.logits
            loss = loss_fn(logits.view(-1, logits.size(-1)), labels.view(-1))

            # Loss 계산
            batch_size = input_ids.size(0)
            total_loss += loss.item() * batch_size
            total_samples += batch_size

            # Accuracy 계산 (패딩 제외)
            predictions = torch.argmax(logits, dim=-1)
            valid_indices = labels != -100  # 패딩이 아닌 부분만 사용
            filtered_predictions = predictions[valid_indices].view(-1).tolist()
            filtered_labels = labels[valid_indices].view(-1).tolist()

            all_predictions.extend(filtered_predictions)
            all_labels.extend(filtered_labels)

    avg_loss = total_loss / total_samples
    accuracy = metric.compute(predictions=all_predictions, references=all_labels)

    return avg_loss, accuracy["accuracy"]

# 평가 실행
val_loss, val_acc = evaluate(model, val_dataloader)

# 결과 출력
print("\n✅ 검증 데이터 성능:")
print(f"Loss: {val_loss:.4f}")
print(f"Accuracy: {val_acc:.4f}")
