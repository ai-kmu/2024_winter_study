from datasets import load_dataset
from transformers import AutoTokenizer
from torch.utils.data import DataLoader

# 모델명 설정
MODEL_NAME = "meta-llama/Llama-3.2-1B"

# 토크나이저 로드
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
tokenizer.pad_token = tokenizer.eos_token  # 패딩 토큰 설정

# KorQuAD 데이터 로드
DATASET_NAME = "KorQuAD/squad_kor_v1"
dataset = load_dataset(DATASET_NAME)


# 전처리 함수 정의
def preprocess_function(examples):
    """
    KorQuAD 데이터를 LLaMA 학습용으로 변환하는 함수
    1. "Q: 질문\nContext: 문맥\nA:" 형식으로 입력을 생성
    2. 정답 부분을 포함하여 `input_ids`를 생성
    3. `labels`는 정답을 제외한 부분을 -100으로 마스킹하여 LLaMA 모델이 학습할 수 있도록 설정
    """

    input_ids_list = []
    attention_mask_list = []
    labels_list = []

    for question, context, answers in zip(examples["question"], examples["context"], examples["answers"]):
        if not answers["text"]:  # 정답이 없는 경우 스킵
            continue

        answer_text = answers["text"][0]  # 첫 번째 정답만 사용

        # 🔥 문맥에서 정답 포함 부분을 유지
        input_text = f"Q: {question}\nContext: {context}\nA:"
        target_text = f" {answer_text} {tokenizer.eos_token}"  # 정답 + EOS 토큰

        # 🔥 토큰화
        tokenized_input = tokenizer(input_text, max_length=256, truncation=True)
        tokenized_target = tokenizer(target_text, max_length=256, truncation=True)

        input_ids = tokenized_input.input_ids + tokenized_target.input_ids  # 입력 시퀀스
        attention_mask = [1] * len(input_ids)

        # 🔥 labels 생성: 프롬프트 부분을 -100으로 마스킹
        labels = [-100] * len(tokenized_input.input_ids) + tokenized_target.input_ids

        # 🔥 패딩 추가 (512 길이 맞추기)
        padding_length = 512 - len(input_ids)
        if padding_length > 0:
            input_ids += [tokenizer.pad_token_id] * padding_length
            attention_mask += [0] * padding_length
            labels += [-100] * padding_length  # `labels`에도 패딩을 -100으로 추가

        # 리스트에 추가
        input_ids_list.append(input_ids)
        attention_mask_list.append(attention_mask)
        labels_list.append(labels)

    # map()이 처리할 수 있는 딕셔너리 형식으로 반환
    return {
        "input_ids": input_ids_list,
        "attention_mask": attention_mask_list,
        "labels": labels_list,  # ✅ labels 추가
    }


# 데이터셋 변환 (훈련 & 검증 데이터)
def load_and_preprocess():
    print(" 데이터셋 전처리 중...")

    #  `remove_columns`을 정확히 지정해서 필요 없는 것만 제거
    tokenized_train = dataset["train"].map(
        preprocess_function, batched=True, remove_columns=["id", "title"]
    )
    tokenized_val = dataset["validation"].map(
        preprocess_function, batched=True, remove_columns=["id", "title"]
    )

    print("✅ 데이터 전처리 완료!")
    print(f"훈련 데이터셋 컬럼: {tokenized_train.column_names}")  # 컬럼 확인용
    print(f"검증 데이터셋 컬럼: {tokenized_val.column_names}")  # 컬럼 확인용

    return tokenized_train, tokenized_val, tokenizer


# DataLoader 설정 (num_workers 증가 및 pin_memory=True 설정)
def create_dataloader(tokenized_train, tokenized_val, batch_size=8):
    # 훈련용 DataLoader
    train_dataloader = DataLoader(
        tokenized_train, batch_size=batch_size, shuffle=True, num_workers=8, pin_memory=True
    )

    # 검증용 DataLoader
    val_dataloader = DataLoader(
        tokenized_val, batch_size=batch_size, shuffle=False, num_workers=8, pin_memory=True
    )

    return train_dataloader, val_dataloader


# 데이터 로딩 및 전처리
tokenized_train, tokenized_val, tokenizer = load_and_preprocess()

# DataLoader 생성
train_dataloader, val_dataloader = create_dataloader(tokenized_train, tokenized_val)

print(f"훈련 DataLoader: {train_dataloader}")
print(f"검증 DataLoader: {val_dataloader}")
